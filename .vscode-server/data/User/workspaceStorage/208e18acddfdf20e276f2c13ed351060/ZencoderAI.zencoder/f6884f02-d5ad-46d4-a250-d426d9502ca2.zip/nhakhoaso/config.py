import os

# Đường dẫn đến file SQLite
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "database", "nhakhoaso.db")
