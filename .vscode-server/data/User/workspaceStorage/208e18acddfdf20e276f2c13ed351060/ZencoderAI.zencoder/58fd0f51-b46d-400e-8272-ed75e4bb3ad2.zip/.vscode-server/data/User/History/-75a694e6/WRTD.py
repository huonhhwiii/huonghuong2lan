import os

# Cấu hình cơ sở dữ liệu MySQL
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Thay đổi mật khẩu nếu cần
    'database': 'QLPhongKhamNhaKhoa',
    'charset': 'utf8mb4'
}