# Đây là file khởi tạo cho package database
from . import benh_nhan
from . import bac_si
from . import phieu_kham